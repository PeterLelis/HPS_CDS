package com.ismail.issuetracking.util;

public class Constants {

    public static final String TOKEN_EXPIRED="EXPIRED";

    public static final String EXPIRED_TOKEN_ERR_MSG="Session Expired";

    public static final String ISSUE_ADDED_SUCCESSFULLY="Issue Added Succefully";
    public static final String ISSUE_EDITED_SUCCESSFULLY="Issue Edited Succefully";
    public static final String ISSUE_DELETED_SUCCESSFULLY="Issue Deleted Succefully";

}
