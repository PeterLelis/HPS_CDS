package com.ismail.its.utils;

public class Constants {
    public static final String TOKEN = "token";
    public static final String SHARED_PERF_NAME="ITS_shared_pref";
    public static final String USER_ID="USER_ID";
}
